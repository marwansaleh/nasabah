#
# TABLE STRUCTURE FOR: nsc_article_comments
#

DROP TABLE IF EXISTS nsc_article_comments;

CREATE TABLE `nsc_article_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `date` datetime NOT NULL,
  `article_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '1',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: nsc_article_images
#

DROP TABLE IF EXISTS nsc_article_images;

CREATE TABLE `nsc_article_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `image_url` varchar(254) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO nsc_article_images (`id`, `article_id`, `image_url`) VALUES (27, 3, 'Slider/pretty-bird-233727.jpg');
INSERT INTO nsc_article_images (`id`, `article_id`, `image_url`) VALUES (28, 3, 'Slider/Pretty_dog.jpg');


#
# TABLE STRUCTURE FOR: nsc_article_visited
#

DROP TABLE IF EXISTS nsc_article_visited;

CREATE TABLE `nsc_article_visited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `visitor_id` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO nsc_article_visited (`id`, `date`, `article_id`, `visitor_id`) VALUES (1, 1427955500, 15, '0');
INSERT INTO nsc_article_visited (`id`, `date`, `article_id`, `visitor_id`) VALUES (2, 1427956646, 15, '9dedafdfa91b9fb30d987773c0d18afd');
INSERT INTO nsc_article_visited (`id`, `date`, `article_id`, `visitor_id`) VALUES (3, 1428069271, 14, '669109f591001f7b904989163556a8cd');
INSERT INTO nsc_article_visited (`id`, `date`, `article_id`, `visitor_id`) VALUES (4, 1428069327, 11, '669109f591001f7b904989163556a8cd');
INSERT INTO nsc_article_visited (`id`, `date`, `article_id`, `visitor_id`) VALUES (5, 1428069381, 6, '669109f591001f7b904989163556a8cd');


#
# TABLE STRUCTURE FOR: nsc_articles
#

DROP TABLE IF EXISTS nsc_articles;

CREATE TABLE `nsc_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(254) NOT NULL,
  `url_title` varchar(254) NOT NULL,
  `url_short` varchar(50) NOT NULL,
  `date` int(11) NOT NULL,
  `synopsis` varchar(254) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(254) NOT NULL,
  `image_type` enum('single','multi') NOT NULL,
  `tags` varchar(254) NOT NULL,
  `types` varchar(254) DEFAULT NULL,
  `allow_comment` tinyint(1) NOT NULL DEFAULT '1',
  `comment` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_title` (`url_title`),
  UNIQUE KEY `url_short` (`url_short`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (1, 1, 'BII Jalin Kerja Sama Reksa Dana dengan PT Maybank GMT Asset Management', 'bii-jalin-kerja-sama-reksa-dana-dengan-pt-maybank-gmt-asset-management', 'http://goo.gl/ln2JFr', 1427648400, 'Target ke depan, Maybank GMT akan menerbitkan Reksa Dana Konvensional dan Reksa Dana Proteksi', '<p>Jakarta – PT Bank Internasional Indonesia Tbk (BII) menjalin kerja sama dengan PT Maybank GMT Asset Management (Maybank GMT), anak usaha Maybank Asset Management Berhad, dalam penjualan produk reksa dana.  Penandatanganan nota kerja sama dilakukan Retail Banking Director BII Lani Darmawan dan President Director Maybank GMT Asset Management Marto Sutiono, dengan disaksikan perwakilan Maybank Asset Management Group, CEO, Nor\'Azamin Salleh dan Risk Director BII Henky Sulistyo.</p>\n<p>Dalam kerja sama ini, BII bertindak sebagai agen penjual (selling agent) yang akan mendistribusikan produk-produk reksa dana yang dikelola Maybank GMT, meliputi Reksa Dana  Maybank GMT Pasar Uang, Reksa Dana  Maybank GMT Dana Fleksi dan Reksa Dana Maybank GMT Dana Ekuitas, serta produk Reksa Dana Proteksi yang akan diluncurkan secara eksklusif bagi nasabah BII.</p>\n<p>Seluruh produk reksa dana ini akan ditawarkan kepada nasabah BII melalui 26 layanan eksklusif wealth management BII Platinum Access dan 198 kantor cabang BII penjual reksa dana.  BII Platinum Access merupakan pengembangan bisnis wealth management sebagai salah satu bentuk layanan priority banking, yang memungkinkan nasabah BII memperoleh end-to-end benefit dengan layanan yang dilakukan secara personalized oleh staf yang ahli dan terlatih di bidang investasi.</p>\n<p>“Produk reksa dana Maybank GMT memperkaya keragaman produk investasi yang ditawarkan melalui BII.  Dengan pilihan produk yang lebih beragam, nasabah memiliki banyak pilihan investasi yang dapat disesuaikan dengan tujuan dan jangka waktu investasi serta profil risiko yang dimilikinya”  kata Lani Darmawan.  “Kemitraan strategis ini selaras dengan misi BII, humanizing financial services untuk senantiasa menyediakan layanan dan produk yang sesuai dengan kebutuhan nasabah,” tambahnya.</p>\n<p>“Reksa Dana Maybank GMT yang berdenominasi rupiah tersebut ditujukan untuk memenuhi kebutuhan nasabah akan produk investasi inovatif yang dapat memberikan imbal hasil kompetitif untuk mencapai tujuan keuangan jangka menengah dan panjang sesuai dengan profil risiko nasabah,” kata Marto Sutiono.  “Maybank GMT Asset Management bekerja sama dengan BII karena BII memiliki jaringan pemasaran yang luas,” lanjutnya</p>', 'Slider/6806087-pretty.jpg', 'single', 'reksa dana,bii,maybank,asset management', 'slider-news', 1, 0, 1, 2, 1427730172, 1427748112, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (3, 2, 'BII Kembali Fasilitasi Pembiayaan Syariah ke Garuda Indonesia', 'bii-kembali-fasilitasi-pembiayaan-syariah-ke-garuda-indonesia', 'http://goo.gl/okub4B', 1427821200, 'Fasilitas pembiayaan musyarakah (Syariah) bernilai USD100 juta kepada Garuda Indonesia, kali ini dengan masa pendanaan 1 (satu) tahun.', '<p>Jakarta - PT Bank Internasional Indonesia Tbk (BII) dan PT Garuda Indonesia (Persero) Tbk (Garuda Indonesia) hari ini meningkatkan kemitraan strategis dalam penyediaan fasilitas pembiayaan Syariah kepada Garuda Indonesia. Pengukuhan kemitraan strategis ini dilakukan dengan penandatanganan perjanjian kerja sama secara simbolis oleh Direktur Keuangan, Risiko & Teknologi Informasi Garuda Indonesia IGN Askhara Danadiputra dan EVP BII Ricky Antariksa, dengan disaksikan Direktur Utama Garuda Indonesia M. Arif Wibowo dan Presiden Direktur BII Taswin Zakaria bertempat di kantor Garuda, Kebon Sirih, Jakarta.</p>\n<p>BII-Maybank, melalui BII Syariah, kembali menyediakan fasilitas pembiayaan musyarakah (Syariah) bernilai USD100 juta kepada Garuda Indonesia, kali ini dengan masa pendanaan 1 (satu) tahun.  Fasilitas ini ditujukan untuk pengembangan usaha Garuda Indonesia Group, termasuk untuk pembiayaan anak perusahaan. Sebelumnya, BII juga memberikan fasilitas yang sama sebesar USD100 juta pada 2014 yang dipergunakan untuk ekspansi bisnis dan operasional Garuda Indonesia.</p>\n<p>Direktur Utama Garuda Indonesia, M. Arif Wibowo dalam kesempatan menyampaikan apresiasi atas dukungan yang telah diberikan oleh BII terhadap Garuda selama ini. “Kerja sama fasilitas pembiayaan ini merupakan bentuk kepercayaan mitra perusahaan terhadap Garuda Indonesia sejalan dengan peningkatan kinerja Garuda sepanjang awal tahun 2015. Kerja sama ini tentunya akan memberikan nilai tambah bagi Garuda Indonesia sejalan dengan program “Quick Wins” yang tengah dilaksanakan saat ini untuk mendukung rencana pengembangan perusahaan ke depannya.”</p>\n<p>“Peningkatan kemitraan strategis dengan Garuda Indonesia dengan menyediakan fasilitas pembiayaan Syariah, selaras dengan strategi BII untuk mendukung BUMN strategis dan top tier client di Indonesia serta strategi Sharia First, yang memberikan pilihan fasilitas Syariah kepada mitra nasabah dalam mendukung ekspansi bisnis, dalam hal ini kepada Garuda Indonesia, sebagai BUMN terkemuka yang bergerak di bidang transportasi udara,” kata Taswin Zakaria.  “Dukungan ini juga selaras dengan misi BII dan Maybank, humanizing financial services, khususnya untuk berada di tengah masyarakat, dengan memberikan layanan dan solusi terbaik kepada mitra bisnis kami beserta komunitasnya,” tambahnya.</p>\n<p>Kemitraan strategis dengan Garuda Indonesia menjadi bagian dari upaya BII mendukung pengembangan bisnis mitra BII, khususnya di bidang industri transportasi dan pariwisata, yang pada akhirnya diharapkan juga dapat ikut memberikan kontribusi positif dalam menggerakkan roda perekonomian nasional.  Disamping itu, BII juga memiliki komitmen yang kuat untuk turun berperan aktif dalam mengembangkan industri perbankan Syariah di tanah air.</p>', 'Slider/pretty-bird-233727.jpg', 'multi', 'bii,pembiayaan,syariah,garuda indonesia', 'highlight|slider-news', 0, 0, 1, 2, 1427740682, 1427885246, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (4, 1, 'Solusi Federation Business Data Lake Terbaru Membuka Jalan Baru Big Data', 'solusi-federation-business-data-lake-terbaru-membuka-jalan-bagi-big-data-untuk-mengubah-setiap-industri-di-seluruh-dunia', 'http://goo.gl/ygojqr', 1427734800, 'Federation Business Data Lake menghadirkan Data Lake berkelas enterprise lengkap untuk memberi jalan bagi Big Data untuk membuat perbedaan besar  dan mengubah setiap industri di seluruh dunia', '<p>EMC corporation (NYSE:EMC) hari ini mengumumkan Federation Business Data lake. Solusi rancangan lengkap yang meliputi storage terkemuka dan teknologi analitis Big Data dari EMC Information Infrastructure, Pivotal dan VMware untuk membantu pelanggan dalam memaksikmalkan era baru Big Data, sehingga memberikan jalan bagi pemahaman baru dan perbedaan besar.</p>\n<p>Dengan proses yang singkat hanya dalam waktu 7 hari, Federation Business Data Lake menyederhanakan tugas rumit yang besar dalam membangun Data Lake dan dirancang untuk memberikan kecepatan, layanan sendiri (self-service) dan skalabilitas bagi perusahaan, sehingga memungkinkan perusahaan untuk mulai menentukan keputusan bisnis yang lebih baikdengan menggunakan analitis Big Data. Federation Business Data Lake bergabung dengan Enterprise Hybrid Cloud Solution sebagai solusi gabungan dari EMC Federation yang akan mendefinisikan kembali infrastruktur untuk memaksimalkan kecepatan dan agility dalam perusahaan TI yang menggunakan Hybrid Cloud dan Data Lakes.</p>\n<p>Pendorong utama dan terpenting dari potensi besar Big data adalah pertumbuhan data dari aplikasi tradisional, aplikasi modern, sensor dan perangkat pintar serta banyaknya data publik baru seperti feed di sosial media. Saat ini kemampuan untuk menerima dan memproses data dapat dilakukan karena adanya perkembangan dari penyimpanan data yang terjangkau dan pengolahan data yang tidak terbatas seiring dengan lahirnya teknologi baru yang dapat menganalisa secara real time dan koneksi langsung melalui aplikasi dan produk baru. Storage dan teknologi analitis ini serta susunan data besar termasuk dalam Business Data Lake.</p>\n<p>Business Data Lakes menjadi prioritas utama perusahaan karena Business Data Lakes mengisi kesenjangan yang dibuat oleh gudang data tradisional. Business Data Lake terdiri dari data terstruktur dan data tidak terstruktur yang berasal dari berbagai sumber dan analisa terfokus pada pembangunan model untuk memprediksi masa depan. Perusahaan yang berhasil menggunakan Data Lakes memanfaatkan data dan model predifktif untuk membuat produk, aplikasi dan model bisnis baru untuk mendefiniskan kembali industri mereka, menjalankan atau meningkatkan peran sebagai \"Pemimpin Pasar\"</p>\n<p>Business Data Lake yang sangat efektif akan memberikan 3 fungsi penting:</p>\n<ul>\n<li>Penyimpanan: Menyimpan data yang terstruktur dan tidak terstruktur untuk seluruh jenis analisa dari banyak sumber yang berbeda, kapasitas campuran dan performa sesuai kebutuhan untuk kasus penggunaan analisa Analisa: Memberikan pengelolaan data yang modern dan peralatan analisa untuk seluruh jenis analisa termasuk Hadoop-based, in-Memory No-SQL dan scale-outMPP.</li>\n<li>Surface & Act: Memberikan data ke pengguna dan aplikasi untuk dapat merubah hasil secara real-time dan mempengaruhi keputusan penting.</li>\n</ul>\n<p>Hingga saat ini, membangun Data Lake yang efektif masih sulit dan rumit. Perusahaan TI yang ingin menggunakan Data Lake harus menerapkan dan mengatur platform analisa yang tepat, dan penyimpanan yang tepat untuk setiap kasus penggunaan analisa, dari Hadoop ke real-time. Ketika lingkungan sudah tercipta, data harus segera diunduh dengan seluruh hak akses yang tepat dan pengelolaan yang diterapkan di susunan data. Penerapan lingkungan dan susunan data adalah tugas yang rumit dan memakan waktu, sehingga menghambatTI untuk memenuhi kebutuhan pengguna bisnis.</p>\n<h3>Solusi Federation Business Data Lake</h3>\n<p>Solusi Federation Business Data Lake mempermudah penerapan Business Data Lake. Produk utama dari perusahaan-perusahaan di EMC Federation, EMC Information Infrastructure, Pivotal and VMware memberikan fungsi utama dari Federation Business Data Lake yang memenuhi kebutuhan fungsional penting – Penyimpanan, Analisa, Surface dan Act.</p>\n<p>Federation Business Data Lake merupakan solusi lengkap yang dapat bekerja dengan cepat dan otomatis, memungkinkan perusahaan TI untuk mendorong kebutuhan bisnis. Analytic layer merupakan sebuah aplikasi virtual yang sempurna beroperasi dengan VMware melalui aplikasi Vblocks® dengan kasus penggunaan predefined analytics dan pengadaan otomatis dan konfigurasi. EMC® Isilon® menyediakan Data Lake StorageFoundation yang memberikan keseimbangan ideal bagi kapasitas dan performa.</p>\n<p>Analytics layer terdiri dari Pivotal Big Data Suite, termasuk PivotalHD yang menampilkan mesin SQL–on-Hadoop terkemuka di dunia, HAWQ. Pivotal Big Data Suite menyediakan SQL berkelas enterprise yang memungkinkan integrasi tanpa adanya ganguan dan dapat bekerja dengan platform analitiss teratas seperti SAS, Tableu dan lain-lain, di luar data yang tersimpan di Hadoop. EMC juga memberikan dua tambahan Business Data Lakes untuk memungkinkan integrasi dengan distribusi Hadoop pilihan pelanggan termasuk Cloudera dan Hortonworks bersama dengan distribusi Hadoop berbasis Platform Open Data di masa depan.</p>', 'Slider/dawn_of_Big_Data.jpg', 'single', 'big data,emc,data lake', 'highlight', 1, 0, 1, 0, 1427797795, 1427797795, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (5, 1, 'Rekening Ponsel Raih Posisi Puncak Digital Brand of The Year 2015', 'rekening-ponsel-raih-posisi-puncak-digital-brand-of-the-year-2015', 'http://goo.gl/krj2D0', 1427648400, 'Digital Brand of The Year 2015 adalah pengukuran posisi perusahaan dan brand di media sosial. Penilaian pemenang ditentukan oleh indeks perusahaan dan brand, berdasarkan kicauan masyarakat di media sosial atas kualitas layanan maupun produk.', '<p>Jakarta - Produk inovatif Rekening Ponsel dari PT Bank CIMB Niaga Tbk (CIMB Niaga), berhasil meraih posisi puncak Digital Brand of The Year 2015 untuk kategori electronic money (e-money). Dengan total indeks sebesar 4.897, Rekening Ponsel mengungguli e-money lainnya di Tanah Air berdasarkan survei yang dilakukan oleh Isentia bekerja sama dengan Biro Riset Infobank.</p>\n<p>Digital Brand of The Year 2015 adalah pengukuran posisi perusahaan dan brand di media sosial. Penilaian pemenang ditentukan oleh indeks perusahaan dan brand, berdasarkan kicauan masyarakat di media sosial atas kualitas layanan maupun produk yang ditawarkan perusahaan-perusahaan tersebut.</p>\n<p>Rekening Ponsel berhasil menarik perhatian sekaligus paling banyak dibicarakan di dunia maya terkait dengan program kerja sama, promosi, serta banyaknya merchant untuk bertransaksi.</p>\n<p>Selain itu, terus meningkatnya jumlah pengguna Rekening Ponsel yang merupakan layanan transaksi perbankan menggunakan nomor ponsel, layaknya rekening tabungan, tanpa mengharuskan penggunanya menjadi nasabah bank manapun, juga sering menjadi topik perbincangan para netters di media sosial.</p>\n<p>\"Kami sangat berterima kasih kepada masyarakat luas khususnya nasabah setia CIMB Niaga atas kepercayaannya menggunakan Rekening Ponsel. Sebagai produk mobile wallet pertama di Asia berdasarkan Museum Rekor Indonesia (MURI), Rekening Ponsel merupakan produk awal kami untuk mendukung inisiatif keuangan inklusif Bank Indonesia dalam menyediakan kemudahan layanan perbankan bagi seluruh lapisan masyarakat Indonesia,\" ujar Budiman Poedjirahardjo, Head of Branch & Branchless Banking CIMB Niaga.</p>\n<p>Rekening Ponsel, lanjut Budiman, juga hadir sebagai kejelian CIMB Niaga mengantisipasi kebutuhan masyarakat khususnya usia produktif yang umumnya sangat akrab dengan dunia teknologi informasi. Salah satunya, mereka memanfaatkan instrumen pembayaran digital untuk memenuhi kebutuhan perbankan sehari-hari.</p>\n<p>Dijelaskan Budiman, sejumlah terobosan dan inovasi telah dilakukan untuk memperkaya fitur Rekening Ponsel. Di antaranya, transfer uang antar nomor ponsel tanpa perlu rekening bank. Selain itu, pengguna juga dapat memanfaatkan Rekening Ponsel untuk belanja di berbagai merchant yang menyediakan beragam promosi seperti Century, Cinema XXI, Blitzmegaplex, Seven Eleven, Indomaret dan Alfa Group, Solaria, Books & Beyond serta merchant-merchant ternama lainnya.  </p>\n<p>Tak hanya itu, untuk penyetoran maupun penarikan tunai menggunakan Rekening Ponsel, tidak lagi terbatas di jaringan ATM maupun kantor cabang CIMB Niaga saja. Lebih dari 20.000 gerai Indomaret dan Alfamart yang tersebar di seluruh Indonesia sudah menggandengkan tangan dengan Rekening Ponsel untuk dapat melayani setor dan tarik tunai Rekening Ponsel.</p>', 'Slider/rekening_ponsel_cimb_niaga.jpg', 'single', 'rekening', 'highlight|slider-news', 0, 0, 1, 1, 1427822447, 1427865396, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (6, 2, 'Mandiri Jadi Bank Ritel Terbaik Indonesia Versi Asian Banker', 'mandiri-jadi-bank-ritel-terbaik-indonesia-versi-asian-banker', 'http://goo.gl/fegpVm', 1427821200, 'Asian Banker menganugerahi penghargaan Best Retail Banking ke Bank Mandiri setelah pada 2014 mampu mencatatkan ROE (Tingkat Pengembalian Ekuitas) 20,95%, memperkuat dana murah dengan porsi mencapai 59,8%, dan catatan finansial lainnya.', '<p>Jakarta - Lembaga riset internasional, The Asian Banker, mendaulat Bank Mandiri sebagai bank ritel terbaik di Indonesia pasca penilaian yang dilakukan terhadap 160 lembaga keuangan di 30 negara. Penghargaan diserahkan The Asian Banker kepada Direktur Consumer Banking Bank Mandiri Hery Gunardi pada ajang The Asian Banker Excellence in Retail Financial Service Award di Singapura.</p>\n<p>Asian Banker menganugerahi penghargaan Best Retail Banking kepada Bank Mandiri setelah pada 2014, Bank Mandiri mampu mencatatkan ROE (Tingkat Pengembalian Ekuitas) 20,95%, memperkuat dana murah dengan porsi mencapai 59,8%, dan sejumlah catatan finansial lainnya.</p>\n<p>Hery Gunardi mengatakan, pencapaian ini merupakan momentum bagi Bank Mandiri untuk menjaga dan meningkatkan konsistensi pertumbuhan bisnis di segmen ritel. Demikian dikutip dari siaran tertulis perseroan yang diterima Jumat (20/3).</p>\n<p>\"Kami ingin terus memperkuat bisnis melalui peningkatan kualitas layanan dan inovasi produk. Selain itu, kami juga fokus meningkatkan akses terhadap layanan keuangan bagi seluruh masyarakat di berbagai wilayah Indonesia,\" kata Hery.</p>\n<p>Chairman of the Excellence in Retail Financial Service Programme Asian Banker Philippe Pailart mengemukakan, proses penilaian program penghargaan perbankan ritel ini berlangsung selama 4 bulan yang melibatkan sejumlah tim peneliti dengan jumlah institusi keuangan yang dinilai mencapai 160 institusi, yang beroperasi di Asia Pacific, Asia Tengah, Timur Tengah, dan Afrika.</p>\n<p>\"Tim riset Asian Banker mengumpulkan data keuangan dari berbagai negara dan menyeleksinya dengan melibatkan para praktisi terkemuka. Melalui program ini, kami berharap bisnis perbankan ritel di kawasan Asia-Pasifik, khususnya Indonesia, dapat terus berkembang,\" kata Pailart.</p>\n<p>Menurut Hery, hingga 2020, potensi pendapatan perbankan nasional untuk segmen mass affluent, mass market, dan small-medium enterprise (SME) masih sangat baik. Untuk itu, Bank Mandiri akan fokus mengembangkan bisnis di segmen ritel ini melalui penguatan jaringan mikro di seluruh Indonesia, memperbaiki ekosistem retail payment dan memperluas akses pasar untuk SME dan rantai bisnisnya</p>\n<p>\"Kami akan mengintegrasikan seluruh jaringan distribusi baik ritel maupun wholesale untuk meningkatkan penetrasi layanan keuangan Bank Mandiri yang tidak terbatas kepada segmen tertentu,\" ujar Hery.</p>\n<p>Pada akhir Desember 2014, laba bersih Bank Mandiri mencapai Rp 19,9 triliun dengan laju pertumbuhan kredit mencapai 12,2% menjadi Rp 530 triliun dibandingkan dengan tahun sebelumnya sebesar Rp 472,4 triliun. Atas kinerja tersebut, aset Bank Mandiri pada akhir Desember 2014 mengalami pertumbuhan year on year sebesar 16,6% menjadi Rp 855 triliun. Total aset itu menjadikan Bank Mandiri sebagai bank terbesar di Tanah Air.</p>\n<p>Memasuki era pasar terbuka ASEAN, Bank Mandiri akan bertransformasi dalam pengembangan bisnis dengan menekankan pada integrasi seluruh potensi Bank Mandiri dan perusahaan anak.</p>\n<p>\"Melalui integrasi ini, kami meyakini Bank Mandiri akan dapat terus tumbuh secara berkesinambungan untuk merealisasikan visi memakmurkan negeri serta menjadi salah satu bank terbaik di kawasan Asia Tenggara,\" tutur Hery.</p>\n<p>Dari sisi intermediasi, Bank Mandiri juga terus memacu pembiayaan ke sektor produktif. Hasilnya, pada akhir 2014, kredit ke sektor produktif tumbuh 13,9% mencapai Rp 410,6 triliun. Kredit investasi tumbuh 9,1% dan kredit modal kerja tumbuh 16,7%. Sektor terkait infrastruktur yaitu konstruksi mencatat akselerasi pertumbuhan sebesar 19,1%, diikuti oleh industri pengolahan sebesar 15,5%.</p>\n<p>Dilihat dari segmentasi, kenaikan penyaluran kredit terjadi di seluruh bisnis, dengan pertumbuhan tertinggi pada segmen mikro yang mencapai 33,2% menjadi Rp 36 triliun pada Desember 2014. Jumlah nasabah kredit mikro juga meningkat sebanyak 119 ribu nasabah. Sementara itu, kredit yang tersalurkan untuk segmen usaha mikro, kecil, dan menengah (UMKM) mencatat pertumbuhan sebesar 13,6% menjadi Rp 73,4 triliun.</p>\n<p>Dana Pihak Ketiga (DPK) juga naik menjadi Rp 636,4 triliun pada akhir 2014 dari Rp 556,3 triliun pada tahun sebelumnya. Dari pencapaian tersebut, total dana murah (giro dan tabungan) yang berhasil dikumpulkan Bank Mandiri mencapai Rp 380,5 triliun, yang terutama didorong oleh peningkatan tabungan sebesar Rp 15,9 triliun hingga mencapai Rp 252,4 triliun.</p>\n<p>Hingga Desember 2014, Bank Mandiri telah melakukan penambahan 262 unit kantor cabang menjadi 2.313 unit, pemasangan 3.830 unit ATM menjadi 15.344 unit, pemasangan 40.000 unit Electronic Data Capture (EDC) menjadi 270.352 unit, serta penambahan jaringan bisnis mikro sehingga menjadi 1.833 unit.dtk</p>', 'Slider/bank-mandiri-2.jpg', 'single', 'mandiri,ritel,asian banker', 'highlight|slider-news', 1, 0, 1, 1, 1427862323, 1427865357, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (7, 2, 'OJK & Perbankan Syariah Gelar Expo iB Vaganza 2015 Sosialisasi Keunggulan Produk', 'ojk--amp--perbankan-syariah-gelar-expo-ib-vaganza-2015-sosialisasi-keunggulan-produk', 'http://goo.gl/5t8GJA', 1427821200, 'Sebagai industri yang relatif baru bertumbuh, industri perbankan dan keuangan syariah perlu terus melakukan sosialisasi dan edukasi agar produk serta jasa layanan dapat dikenal dan dimanfaatkan untuk memenuhi kebutuhan masyarakat luas.', '<p>Jakarta - Otoritas Jasa Keuangan (OJK) bersama Industri Perbankan Syariah akan menggelar acara Expo iB (Islamic Banking) Vaganza 2015 sebagai upaya untuk semakin memperkenalkan dan meningkatkan  pemahaman kepada masyarakat mengenai keunggulan produk dan layanan perbankan syariah.</p>\n<p>Surakarta (Solo) menjadi kota penyelenggara pertama kegiatan Expo iB Vaganza tahun 2015 dari rencana kegiatan di lima belas (15) kota besar di Jawa, Sumatera, Kalimantan, Sulawesi dan Nusa Tenggara Barat sepanjang tahun ini. Kegiatan di Kota Solo digelar dari tanggal 7 sampai dengan 11 Januari 2015  bertempat di Solo Square.</p>\n<p>OJK dalam keterangan persnya di Jakarta, Rabu (7/1) menjelaskan, pemilihan kota Solo mempertimbangkan kesuksesan penyelenggaraan kegiatan yang sama pada tahun 2013. Selain itu, Solo selama ini telah menjadi lahan subur untuk pengembangan industri perbankan dan keuangan syariah yang market share perbankan syariah-nya telah melampaui market share perbankan syariah nasional.</p>\n<p>Expo akan dimeriahkan dengan berbagai acara, di antaranya talkshow edukasi literasi keuangan, sosialisasi produk dan layanan perbankan syariah dengan nara sumber dari Departemen Perbankan Syariah OJK Pusat, Perwakilan OJK Solo, pelaku Industri Jasa Keuangan dan Tokoh Masyarakat. Acara lainnya adalah penyerahan CSR Perbankan Syariah, aneka lomba (iB Idol, mewarnai, paduan suara anak, fashion show anak, dan lain-lain), hiburan (akustik, stand up commedy, dan lain-lain), aneka permainan, dan pembagian undian harian.</p>\n<p>OJK menilai, sebagai industri yang relatif baru bertumbuh, industri perbankan dan keuangan syariah nasional perlu terus melakukan sosialisasi dan edukasi publik (campaign) agar produk serta jasa layanan syariah yang semakin beragam dan berdaya saing dapat dikenal dan dimanfaatkan untuk memenuhi kebutuhan masyarakat luas. Disamping itu juga agar dapat berkontribusi secara nyata dan optimal dalam pertumbuhan dan perkembangan perekonomian nasional yang berkesinambungan.</p>\n<p>\"Saat ini market share bank syariah di Indonesia berkisar 5% dari total aset bank secara nasional. Jumlah nasabah bank syariah saat ini  masih di bawah 10 juta orang, sehingga potensi peningkatan nasabah perbankan syariah masih sangat besar mengingat jumlah penduduk usia produktif Indonesia yang terus bertambah,\" papar OJK.</p>\n<p>Hingga Oktober 2014 jumlah industri Bank Umum Syariah (BUS) tercatat sebanyak 12 bank, jumlah Unit Usaha Syariah (UUS) sebanyak 22 bank, BPRS sebanyak 163 bank, dan jaringan kantor sebanyak 2.950. Adapun total aset (khusus BUS dan UUS) adalah sebesar Rp260,366 triliun, pembiayaan sebesar Rp196,491 triliun, dan penghimpunan DPK perbankan syariah adalah sebesar Rp207,121 triliun.</p>\n<p>Maka, OJK memandang perlu bahwa pengembangan industri perbankan syariah di Indonesia memerlukan strategi yang tepat khususnya dalam mengkomunikasikan produk dan layanan perbankan syariah ke masyarakat tanpa menghilangkan ciri khasnya.</p>\n<p>\"Selain itu pengembangan layanan perbankan syariah juga memerlukan sumber daya manusia yang memadai serta fasilitas yang bisa dinikmati kapanpun oleh nasabah dan memiliki jangkauan (jaringan kantor) yang luas.\"</p>', 'Slider/Bank_Syariah_Mandiri.jpg', 'single', 'ojk,syariah,vaganza', 'highlight|slider-news', 0, 0, 1, 0, 1427862814, 1427876299, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (8, 3, 'Listing Perdana, Saham Mitra Keluarga langsung Beri Gain Hingga 25%', 'listing-perdana--saham-mitra-keluarga-langsung-beri-gain-hingga-25-persen', 'http://goo.gl/e1FZbB', 1427821200, 'Harga saham MIKA di awal perdagangan sempat menyentuh angka tertinggi di level Rp21.200 per lembar saham, dan harga terendah di level Rp19.000 per lembar saham', '<p>Jakarta - PT Mitra Keluarga Karyasehat Tbk (MIKA) melakukan pencatatan saham perdananya di papan perdagangan Bursa Efek Indonesia (BEI). Membuka perdagangan perdana sesi pertama, tepatnya pukul 09.00, saham MIKA langsung memberikan keuntungan (gain) bagi investor dengan kenaikan harga sebesar 25% dari harga penawaran awal yang sebesar Rp17.000 per lembar saham menjadi Rp21.000 perlembar saham.</p>\n<p>Adapun harga saham MIKA di awal perdagangan sempat menyentuh angka tertinggi di level Rp21.200 per lembar saham, dan harga terendah di level Rp19.000 per lembar saham. Selanjutnya, hingga 10 menit pertama proses perdagangan saham MIKA stabil di kisaran harga Rp20.000 per lembar saham.</p>\n<p>Direktur Utama Kresna Sekuritas, Michael Steven mengatakan, peningkatan harga saham MIKA di awal perdaganan perdana telah diprediksi mengingat dalam masa penawaran, antusiasme investor sangat tinggi. \"Jadi analis yang mengatakan saham MIKA sangat mahal, mungkin perlu dikaji kembali,\" kata Michael seusai acara Pencatatan Saham Perdana (Listing) di BEI, Selasa (24/3).</p>\n<p>Dia mengungkapkan, saat masa penawaran terjadi kelebihan permintaan (oversubscribe) hingga 10,3 kali untuk investor institusi. \"Memang terlihat kecil, tetapi nilai kelebihan permintaan itu sekitar Rp45 triliun. Ini sangat dashat. Komposisi investor institusi antara lain asing 53% dan lokal 47%,\" ungkap Michael.</p>\n<p>Sementara itu, kelebihan permintaan juga datang dari investor ritel yakni sebanyak 8,3 kali. \"Porsi ritel 90% fix, dan 10% pool. Nah yang oversubscribe 8,3 kali itu dari yang pool,\" pungkas Michael.</p>\n<p>Sesuai rencana, dengan perolehan dana segar hasil IPO yang senilai Rp4,5 triliun, MIKA berencana membangun tambahan 7 RS baru dalam 5 tahun ke depan. \"Tahun ini kita bangun 1 RS Mitra Keluarga di Kali Deres, Jakarta. Secara keseluruhan dari rencana 7 RS baru itu, 1 RS akan dibangun di Surabaya, 6 di Jabodetabek. Tetapi kita buka kesempatan untuk bangun lebih dari 7 rumah sakit baru kalau memungkinkan,\" jelas Direktur Utama Mitra Keluarga, Ir. Rustiyan Oen, MBA, di kesempatan yang sama.</p>\n<p>Untuk membangun 1 RS baru, lanjut Rustiyan, pihaknya menghabiskan dana investasi Rp200-Rp300 miliar. Ke depan, selain pengembangan RS baru, MIKA juga akan terus meningkatkan kualitas sumber daya manusia.</p>\n<p>Dari sisi kinerja, Rustyan menambahkan bahwa sepanjang 2015 perkiraan laba MIKA tumbuh di atas 20%. Dengan adanya penambahan rumah sakit baru, Rustyan berharap pertumbuhan laba dalam 2-3 tahun ke depan, sama dengan capaian pertumbuhan MIKA di lima tahun terakhir.</p>\n<p>Sementara Direktur Utama BEI, Ito Warsito mengatakan, MIKA merupakan emiten kedua yang melakukan listing di awal tahun ini. Dia berharap saham MIKA akan Menjadi salah satu koleksi investor. \"Kami yakin pertumbuhan industri healt care semakin pesat. Sehingga RS mitra Keluarga bisa tumbuh bersama pasar modal,\" pungkas Ito.</p>', 'Slider/stock-market-down.png', 'single', 'saham,mitra keluarga', 'highlight', 0, 0, 1, 0, 1427887661, 1427887661, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (9, 4, 'BPJS Langgar PKS CoB, AAJI Surati Presiden', 'bpjs-langgar-pks-cob--aaji-surati-presiden', 'http://goo.gl/Rxbejm', 1427821200, 'BPJSK secara sepihak telah mengeluarkan draft addendum PKS CoB pada bulan Oktober yang lalu sebelum CoB dapat diimplementasikan sepenuhnya', '<p>Jakarta - Industri Asuransi Jiwa Indonesia senantiasa mendukung kebijakan pemerintah, salah satunya terkait program Jaminan Kesehatan Nasional (JKN). Untuk itu AAJI secara intensif melakukan komunikasi dengan Tim BPJS Kesehatan (BPJSK) selaku badan penyelenggara JKN sejak akhir tahun 2013 bersama-sama dengan Asosiasi Asuransi Umum Indonesia (AAUI).</p>\n<p>Terhitung sejak April s/d Juni 2014 terdapat 30 Perusahaan Asuransi Komersial yang telah menandatangani Perjanjian Kerjasama Coordination of Benefit (CoB). Namun sebelum CoB dapat diimplementasikan sepenuhnya, BPJSK secara sepihak telah mengeluarkan draft addendum PKS CoB pada bulan Oktober yang lalu.</p>\n<p>“Dengan adanya draft addendum itu, otomatis Cob tidak bisa diterapkan,” ungkap Maryoso Sumaryono, Ketua Bidang Regulasi dan Bert Practice AAJI di Jakarta, Jumat (12/12).</p>\n<p>Dia mengungkan, ada beberapa hal yang menjadikan CoB tidak dapat diimplementasikan antara lain, bahwa proses Pendaftaran Peserta dan pembayaran iuran BPJSK harus dilakukan oleh Badan Usaha secara langsung kepada BPJSK dari sebelumnya ada pilihan untuk dilakukan melalui Asuransi Komersial (satu pintu).</p>\n<p>Kemudian, keterbatasan jumlah Non Fasilitas Kesehatan BPJSK yang dapat menerima Peserta CoB menjadi 16 Rumah Sakit dari sebelumnya sejumlah 20 Rumah Sakit, dimana sebelumnya AAJI telah mengusulkan sebanyak sekitar 1200 Rumah Sakit di seluruh Indonesia.</p>\n<p>Hal lainnya,kualitas Layanan Fasilitas Kesehatan Primer (Rawat Jalan Tingkat Pertama) yang belum memadai dan penyebarannya belum merata, penghapusan manfaat CoB untuk Rawat Jalan Tingkat Lanjut di Poli Eksekutif, da tidak diberlakukan CoB untuk asuransi individu.</p>\n<p>Selanjutnya, pada prosedur Rawat Jalan Tingkat Lanjutan di Non Fasilitas Kesehatan BPJSK yang dapat menerima Peserta CoB yaitu Prosedur Berjenjang hanya dapat dilakukan pada Fasilitas Kesehatan Primer BPJSK, dan keharusan untuk naik kelas kamar perawatan.</p>\n<p>Mengacu pada butir-butir di atas, kata Maryoso, mengakibatkan sangat kecil kemungkinan terjadinya sharing risiko sehingga Penurunan Premi yang diharapkan oleh Badan Usaha tidak dapat terjadi, malah Potensi Ekonomi Biaya Tinggi menjadi semakin besar.</p>\n<p>Maka, dengan melihat adanya berbagai hal tersebut di atas, dan untuk mendukung realisasi peta jalan JKN, maka AAJI mengusulkan penyempurnaan petunjuk teknis CoB yang melibatkan seluruh pemangku kepentingan, dengan ruang lingkup skema CoB yang terdiri dari; pertama, proses pendaftaran peserta BPJSK dapat dilakukan melalui 2 cara, dilakukan oleh Badan Usaha secara langsung ke BPJS, atau dilakukan oleh Badan Usaha melalui Asuransi Komersial.</p>\n<p>Kedua, seluruh tipe RS dapat digunakan sebagai Fasilitas Kesehatan CoB. Ketiga, prosedur berjenjang di Non Fasilitas Kesehatan BPJSK dapat diakomodir. Dan keempat skema CoB mencakup peserta individu. AAJi juga mengusulkan revisi batas waktu pendaftaran peserta dikembalikan pada Peraturan Presiden No. 12 Tahun 2013 Pasal 6 ayat 2, yaitu Tahap 2 adalah 1 Januari 2019.</p>\n<p>“Ini pandangan AAJI dalam menyikapi implementasi JKN, dimana hal ini akan memberikan dampak positif kepada masyarakat Indonesia dalam meningkatkan kesejahteraan masyarakat dan pada akhirnya akan meningkatkan penetrasi asuransi di Indonesia,” kata Maryoso.</p>\n<p>Dia menambahkan, hal-hal tersebut di atas sudah disampaikan secara tertulis kepada BPJSK dan juga kepada Presiden Republik Indonesia.</p>', 'Slider/bpjs_media_center.jpg', 'single', 'bpjs', 'highlight', 0, 0, 1, 0, 1427887987, 1427887987, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (10, 4, 'Kepala BKPM Bantah Proyek Cilamaya Syarat Jepang Tanam Investasi', 'kepala-bkpm-bantah-proyek-cilamaya-syarat-jepang-tanam-investasi', 'http://goo.gl/8L1c4l', 1427821200, 'Kepala BKPM Franky Sibarani membantah proyek pembangunan Pelabuhan Cilamaya merupakan syarat agar Jepang mau memperbesar investasinya di Indonesia', '<p>JAKARTA - Kepala Badan Koordinasi Penanaman Modal (BKPM) Franky Sibarani membantah proyek pembangunan Pelabuhan Cilamaya merupakan syarat khusus yang diajukan Jepang agar mau memperbesar investasinya di Indonesia. Hal tersebut diucapkan Franky saat menggelar jumpa pers terkait nilai investasi yang dibawa pulang pemerintah pasca kunjungan Presiden Jokowi ke Jepang dan Tiongkok. <br /><br />\"Tidak (benar proyek Pelabuhan Cilamaya syarat dari Jepang agar mau berinvestasi di Indonesia),\" ujar Franky di Kantor BKPM, Jakarta, Rabu (1/4/2015). <br /><br />Namun, dia mengakui bahwa kunjungan Presiden Jokowi ke Jepang juga membahas terkait proyek Pelabuhan Cilamaya. Bahkan kata Franky, para investor asal Jepang menyampaikan kepada pemerintah akan mendalami investasi pelabuhan yang saat ini menjadi polemik tersebut. <br /><br />\"Jadi memang disinggung soal Cilamaya, tapi posisi kita kan sekarang sedang menunggu terkait dengan 150 hektar lahan sawah, pipa gas, dan terkait dengan Pertamina,\" kata Franky. <br /><br />Menurut Franky, salah satu yang ditawarkan pemerintah kepada Jepang dan Tiongkok adalah investasi di sektor Kemaritiman terutama untuk mendukung program tol laut yang dicanangkan pemerintah. Sayangnya kata dia, Jepang masih ingin mendalami berbagai celah investasi di sektor maritim. <br /><br />Sementara Tiongkok justru melangkah lebih dulu. Negeri Tirai Bambu ini sudah berkomitmen berinvestasi disektor maritim sebesar 2 miliar dollar AS. <br /><br />Sebelumnya, proyek pembangunan Pelabuhan Cilamaya menjadi polemik di dalam negeri. Pasalnya, berbagai pihak yaitu Kementerian ESDM, Pertamina dan SKK Migas menolak pembangunan Pelabuhan Tersebut karena diyakini bisa mengganggu operasional Blok Migas Offshore North West Jawa (ONWJ). <br /><br />Sementara itu, Kementerian Perhubungan (Kemenhub) mengatakan bahwa proyek yang digagas oleh Badan Perencanaan Pembangunan Nasional (Bappenas) itu tetap akan jalan terus.</p>', 'Slider/kapal_di_pelabuhan.jpg', 'single', 'bkpm,cilamaya,investasi', NULL, 0, 0, 1, 0, 1427888508, 1427888533, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (11, 3, 'Tim Anti Mafia Migas: Tidak Benar Pemerintah Lepas Harga BBM ke Mekanisme Pasar', 'tim-anti-mafia-migas--tidak-benar-pemerintah-lepas-harga-bbm-ke-mekanisme-pasar', 'http://goo.gl/t5TGKq', 1427821200, 'Faisal Basri menegaskan, pemerintah tidak melepaskan pembentukan harga bahan bakar minyak (BBM) kepada mekanisme pasar.', '<p>JAKARTA – Ketua Tim Reformasi Tata Kelola Minyak dan Gas Bumi (Migas) atau Tim Anti Mafis Migas, Faisal Basri menegaskan, pemerintah tidak melepaskan pembentukan harga bahan bakar minyak (BBM) kepada mekanisme pasar. <br /><br />\"Jadi tidak benar kalau dikatakan dilepaskan sepenuhnya pasar, karena pemerintah menentukan margin 5-10 persen. Terlepas dari ketentuan ini menimbulkan komplikasi, tapi intinya pemerintah akan hadir di pasar. Tidak membiarkan begitu saja pada mekanisme pasar,\" terang Faisal, di Jakarta, Rabu (1/4/2015). <br /><br />Pemerintah menetapkan margin 5-10 persen berdasarkan payung hukum yakni Perpres 191 tahun 2014 jo. Permen ESDM No. 39 tahun 2014, di mana melalui ketentuan tersebut pemerintah mengatur harga tiga kategori atau jenis BBM. <br /><br />Pertama, jenis BBM tertentu atau BBM yang masih disubsidi, yakni solar dengan subsidi tetap Rp 1.000 per liter, serta minyak tanah yang diberikan subsidi mengambang. Kedua, jenis BBM penugasan yang didistribusikan di luar Jawa, Madura, dan Bali (Jamali). Harga BBM penugasan menggunakan formula sesuai harga dasar ditambah ongkos distribusi di luar Jamali. <br /><br />\"Terlepas dari apakah ada kecenderungan di luar Jamali itu lebih mahal kalau dilepas, ya enggak juga. Harga di Balikpapan lebih murah dari Rengasdengklok karena di Balikpapan ada kilang, di Dumai ada kilang,\" lanjut dia. <br /><br />Terakhir adalah jenis BBM umum dimana harganya diserahkan perusahaan atau badan usaha, tetapi pemerintah memberikan batas atas dan bawah keuntungan yang bisa diambil, yakni 5 persen dan 10 persen dari harga dasar. <br /><br />Sebelumnya, Mantan Menteri Koordinator Ekonomi Kwik Kian Gie menilai Presiden Joko Widodo sudah bertindak menyalahi Undang-Undang Dasar 1945 karena menerapkan harga bahan bakar minyak sesuai dengan harga pasar. <br /><br />\"Presiden Jokowi sudah melanggar konstitusi,\" kata Kwik dalam sebuah diskusi di Kompleks Parlemen, Senayan, Jakarta, Selasa (31/3/2015). <br /><br />Ekonom tersebut menjelaskan, pada 2003, Mahkamah Konstitusi telah membatalkan Pasal 28 ayat (2) Undang-Undang Nomor 22 Tahun 2001 tentang Minyak dan Gas Bumi.  Ketentuan pasal ini menyerahkan proses pembentukan harga eceran bahan bakar minyak (BBM) dalam negeri sepenuhnya kepada mekanisme persaingan pasar.</p>', 'Slider/eksplorasi-migas.jpg', 'single', 'migas', NULL, 0, 0, 1, 1, 1427888895, 1427888895, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (12, 2, 'BI Sempurnakan Aturan Jakarta Interbank Offered Rate (JIBOR)', 'bi-sempurnakan-aturan-jibor', 'http://goo.gl/xXSxwU', 1427821200, 'Bank Indonesia merevisi sistem penetapan suku bunga penawaran antarbank atau Jakarta Interbank Offered Rate (JIBOR) penerbitan Peraturan Bank Indonesia (PBI) No.17/2/PBI/2015', '<p>Bank Indonesia merevisi sistem penetapan suku bunga penawaran antarbank atau <em id=\"tinymce\" class=\"mceContentBody \" dir=\"ltr\">Jakarta Interbank Offered Rate (</em>JIBOR), seiring dengan penerbitan Peraturan Bank Indonesia (PBI) No.17/2/PBI/2015 tanggal 26 Maret 2015 tentang Suku Bunga Penawaran Antarbank.  <br /><br />\"PBI ini mengatur penetapan bank kontributor yaitu bank yang menyampaikan suku bunga penawaran untuk tenor satu tahun ke bawah, serta mengatur kewajiban bank kontributor untuk meminjamkan rupiah pada tingkat suku bunga yang disampaikan bank tersebut sepanjang memenuhi batasan waktu dan batasan lainnya, seperti jangka waktu dan jumlah nominal peminjaman,\" sebut Direktur Eksekutif Departemen Komunikasi BI Tirta Segara dalam siaran pers yang diterima <em>Kompas.com</em> Rabu (1/4/2015).<br /><br id=\"tinymce\" class=\"mceContentBody \" />PBI ini, lanjut dia, diharapkan akan meningkatkan kredibilitas JIBOR sebagai suku bunga acuan pasar untuk tenor satu tahun ke bawah.<br /><br />\"Pembentukan suku bunga acuan pasar uang untuk tenor satu tahun ke bawah juga akan melengkapi imbal hasil (<em>yield</em>) Surat Utang Negara yang berjangka waktu 2 sampai d. 30 tahun. Sehingga Indonesia akan memiliki kurva imbal hasil (<em>yield curve</em>) yang lengkap antara tenor <em>overnight</em> sampai 30 tahun,\" ucapnya.<br /><br />Ia menyebutkan, kurva imbal hasil yang lengkap sangat penting bagi berjalannya transmisi kebijakan moneter (<em>monetary transmission channel</em>), karena kurva imbal hasil yang lengkap mengandung faktor ekspektasi pasar terhadap arah inflasi, suku bunga, dan prospek ekonomi ke depan. Selain itu, dengan instrumen pasar yang berkembang dan semakin banyak akan semakin luas pula pilihan bagi investor untuk melakukan diversifikasi portofolio, sehingga akan meningkatkan ketahanan sistem keuangan.<br /><br />Adapun definisi JIBOR dalam PBI ini adalah rata-rata dari suku bunga indikasi pinjaman tanpa agunan (<em>unsecured</em>) yang ditawarkan dan dimaksudkan untuk ditransaksikan oleh bank kontributor kepada bank kontributor lain untuk meminjamkan rupiah untuk tenor tertentu di Indonesia.  JIBOR ditetapkan dalam tenor <em>overnight</em> (O/N), 1 minggu, 1 bulan, 3 bulan, 6 bulan, dan 12 bulan. <br /><br />Menurut dia, terdapat 21 bank yang menjadi kontributor, dan suku bunga yang ditawarkan dapat ditransaksikan secara riil di antara 21 bank kontributor tersebut dalam kurun waktu 10 menit sesudah <em>announcement</em> time pukul 10.00 WIB. Data JIBOR akan tersedia pada setiap hari kerja dan dipublikasikan melalui situs Bank Indonesia.</p>', 'Slider/bank_indonesia.jpg', 'single', 'jibor,bi', 'highlight', 0, 0, 1, 0, 1427889520, 1427889520, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (13, 2, 'Pasar Jasa Audit Belum Akan Berubah', 'pasar-jasa-audit-belum-akan-berubah', 'http://goo.gl/9QQhtC', 1427821200, 'Dominasi The Big Four di pasar jasa audit Indonesia belum tergoyahkan, dengan Ernst &amp; Young tetap kokoh di puncak. Peraturan yang diterbitkan Februari 2011 lalu membuat mereka makin kuat menjejak pasar', '<p>Industri jasa audit keuangan telah berkembang pesat dalam beberapa dekade terakhir. Tak hanya di negara-negara yang secara ekonomi sudah maju, besarnya permintaan atas jasa audit juga merambah kawasan <em>emerging market</em>. Indonesia misalnya. Kemajuan pasar modal di kawasan tersebut berimbas pada kebutuhan perusahaan akan opini dan penilaian pihak ketiga. Salah satu yang memerlukannya adalah laporan keuangan perusahaan.</p>\n<p>Perusahaan yang dimaksud di sini tentunya perusahaan publik. Memang, beberapa industri, perbankan misalnya, juga mensyaratkan hal tersebut. Namun menurut peraturan perundangan, perusahaan yang sudah <em>go public</em> itulah yang memang paling berkewajiban mencantumkan pernyataan auditor independen dari laporan keuangan mereka.</p>\n<p>Bagi perusahaan yang sudah mencatatkan diri di bursa, men-<em>disclose</em> informasi yang bersinggungan dengan kepentingan publik merupakan sebuah keharusan. Di Indonesia, pasal 86 ayat 1a UU Pasar Modal No 8/1995 mensyaratkan emiten atau perusahaan publik untuk memberikan laporan secara berkala kepada Bapepam dan masyarakat.</p>\n<p>Laporan berkala yang dimaksud adalah informasi reguler tentang kegiatan usaha dan keadaan keuangan emiten atau perusahaan publik. Bagi masyarakat (baca investor), laporan tersebut dibutuhkan untuk keputusan investasi. Salah satu laporan yang wajib mendapatkan opini auditor publik, dalam hal ini kantor akuntan publik (KAP), adalah laporan keuangan tahunan perusahaan.</p>\n<p>Salah satu jasa yang diberikan KAP adalah atestasi. Mengutip Wikipedia, atestasi merupakan suatu pernyataan pendapat atau pertimbangan yang diberikan oleh pihak yang independen dan kompeten, yang menyatakan apakah asersi (assertion) suatu entitas sudah sesuai atau belum dengan kriteria yang telah ditetapkan. Asersi sendiri adalah suatu pernyataan yang dibuat oleh satu pihak yang dimaksudkan untuk digunakan oleh pihak lain, contoh asersi dalam laporan keuangan historis adalah adanya pernyataan manajemen bahwa laporan keuangan sesuai dengan prinsip akuntansi yang berlaku umum.</p>\n<p>Bagi KAP, pesatnya pertumbuhan pasar modal Indonesia merupakan sebuah berkah. Pasar modal yang tumbuh akan menarik banyak perusahaan untuk masuk bursa. Hal ini berarti makin besar pula pasar potensialyang bisa menjadi klien KAP. Dalam satu dekade terakhir, pasar modal nasional berhasil membukukan kinerja mengaggumkan. Dalam kurun waktu tersebut, total emisi saham dan obligasi korporasi telah meningkat dua kali lipat, yakni dari Rp263 triliun pada 2001 menjadi Rp539,71triliun pada awal November 2011. Sejak awal sejarah pasar modal Indonesia hingga saat ini, tercatat sudah 537 emiten yang melakukan emisi saham dan196 emiten yang melakukan emisi obligasi.</p>', 'Slider/Audit-Checklist.jpg', 'single', 'audit', NULL, 0, 0, 1, 0, 1427889808, 1427889808, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (14, 2, 'Cetak Laba Rp 384,6 M, Sinarmas MSIG Life Siap Gandakan Bisnis Baru di 2015', 'cetak-laba-rp-384-6-m--sinarmas-msig-life-siap-gandakan-bisnis-baru-di-2015', 'http://goo.gl/Yd3Dr3', 1427821200, 'Kontribusi unit bisnis Syariah terhadap total new business ditargetkan sebesar 25%, naik dari pencapaian 23% di tahun 2014', '<p>Jakarta – PT Asuransi Jiwa Sinarmas MSIG (Sinarmas MSIG Life), joint venture antara PT Asuransi Jiwa Sinarmas dan Mitsui Sumitomo Insurance Co. Ltd, asal Jepang, mencetak Laba Bersih sebesar Rp 384,6 miliar dengan total Pendapatan Premi Bersih mencapaiRp 7,4 triliun. Keberhasilan ini mendorong optimism perusahaan untuk menggandakan target new business growth pada tahun 2015 ini.</p>\n<p>“Raihan new business growth menegaskan peningkatan kepercayaan masyarakat Indonesia kepada Sinarmas MSIG Life akan solusi produk dan layanan finansial yang kami berikan, sekaligus memperlihatkan kenaikan kesadaran masyarakat tentang pentingnya berasuransi dan perlindungan keuangan di masa depan,” papar Johnson Chai, Presiden Direktur Sinarmas MSIG Life di Jakarta, awal pekan ini.</p>\n<p>Jumlah nasabah Sinarmas MSIG Life juga mengalami lonjakan hingga 67% dari sekitar 600.000 pada 2013 menjadi hampir 1 juta nasabah individu maupun kelompok, di akhir 2014. Sementara, rasio pencapaian solvabilitas dengan metode Risk Based Capital (RBC) perusahaan mencapai 747,95% untuk konvensional dan 64,26% untuk syariah.</p>\n<p>Dari komposisi produk, Sinarmas MSIG Life membukukan pertumbuhan premi regular sebesar 158% dengan premi regular unit link meningkat sebesar 173% dari tahun sebelumnya. “Ini memperlihatkan semakin berkembangnya minat nasabah terhadap produk asuransi yang menawarkan perlindungan jangka panjang terkait investasi yang tidak saja memberikan proteksi, namun juga berpotensi memberikan manfaat lebih secara jangka panjang,” lanjut Johnson Chai.</p>\n<p>Lini syariah yang sedang berkembang juga menunjukkan pertumbuhan yang signifikan hingga 117% sepanjang tahun 2014..</p>\n<p>Menurut Johnson Chai, pncapaian positif Sinarmas MSIG Life tahun lalu tentunya terkait erat dengan strategi pemasaran yang diperkuat jalur distribusi paling komplet, yakni 1) Agency, 2) Bancassurance, 3) Direct Marketing-Telemarketing (DMTM) dan 4) Employee Benefit. Kontribusi keempat jalur distribusi tersebut terhadap new business annual premium equivalent (APE) secara berurutan adalah sebesar 38%, 20%, 9% dan 33%.</p>\n<p>Ke depan, kata Johnson Chai, pihaknya optimis dapat menutup tahun 2015 dengan raihan yang semakin positif. “Perusahaan mengestimasi total new business growth mencapai dua kali lipatnya di akhir tahun 2015 ini.” Sementara itu, lanjut dia, kontribusi unit bisnis Syariah terhadap total new business ditargetkan sebesar 25%, naik dari pencapaian 23% di tahun 2014. Produk regular unit link yang diprediksi masih akan digemari tahun ini ditargetkan tumbuh dua kali lipatnya.</p>', 'Slider/Sinar_mas.jpg', 'single', 'sinarmas', NULL, 0, 0, 1, 1, 1427890287, 1427890287, 1, 1);
INSERT INTO nsc_articles (`id`, `category_id`, `title`, `url_title`, `url_short`, `date`, `synopsis`, `content`, `image_url`, `image_type`, `tags`, `types`, `allow_comment`, `comment`, `published`, `view_count`, `created`, `modified`, `created_by`, `modified_by`) VALUES (15, 3, 'Lanjutkan Kenaikan, Rupiah Menguat ke Kisaran Rp 12.900 Per Dollar AS', 'lanjutkan-kenaikan--rupiah-menguat-ke-kisaran-rp-12-900-per-dollar-as', 'http://goo.gl/EZeH4r', 1427907600, 'Nilai tukar rupiah terhadap dollar AS pada awal perdagangan pagi masih melanjutkan kenaikan. Rupiah di pasar spot berhasil menguat di bawah 13.000.', '<p>Data <em>Bloomberg</em> pukul 08.35 WIB, mata uang Garuda menguat ke Rp 12.985 per dollar AS, dibanding penutupan kemarin pada level 13.048.<br /><br />Rupiah hari ini diperkirakan bergerak menguat. Indeks dollar AS yang tertekan diharapkan memberi ruang penguatan bagi mata uang regional, termasuk mata uang garuda. <br /><br />\"Di hari terakhir perdagangan minggu ini penguatan rupiah berpeluang bertahan,\" demikian Samuel Sekuritas Indonesia dalam risetnya, pagi ini. <br /><br />Kemarin rupiah kembali menguat bersamaan dengan penguatan mata uang lain di Asia walaupun inflasi tahunan tercatat naik tipis. Inflasi bulanan pertama terlihat di Maret terutama akibat kenaikan harga BBM serta elpiji 12 kilogram. <br /><br />Harga beras memang dinyatakan naik akan tetapi kenaikannya sudah jauh lebih rendah. Bahkan secara keseluruhan harga makanan mengalami deflasi di Maret. Efek total dari kenaikan harga BBM di Maret akan lebih terasa di April. <br /><br />Dari eksternal, indeks dollar AS turun hingga dini hari tadi setelah mayoritas data AS yang diumumkan lebih buruk dari periode sebelumnya. ISM manufacturing PMI AS turun ke level terendah dalam 14 bulan terakhir. <br /><br />Data AS yang memburuk seakan memberikan konfirmasi pernyataan Yellen di akhir pekan minggu lalu bahwa kenaikan suku bunga tidak akan agresif tahun ini khususnya jika data ekonomi AS tidak sesuai harapan. Pada saat yang bersamaan harga minyak naik 3,6 persen. Malam ini ditunggu data <em>initial jobless claims</em> AS yang diperkirakan turun. Dollar AS pun berpeluang melanjutkan pelemahannya di Asia hari ini.</p>', 'Slider/stock-market-up.jpg', 'single', '', NULL, 0, 0, 1, 5, 1427954624, 1427954638, 1, 1);


#
# TABLE STRUCTURE FOR: nsc_category
#

DROP TABLE IF EXISTS nsc_category;

CREATE TABLE `nsc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `parent` int(11) NOT NULL,
  `is_menu` tinyint(1) NOT NULL DEFAULT '0',
  `is_home` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO nsc_category (`id`, `name`, `slug`, `parent`, `is_menu`, `is_home`, `sort`) VALUES (1, 'Laporan Utama', 'laporan-utama', 0, 1, 1, 0);
INSERT INTO nsc_category (`id`, `name`, `slug`, `parent`, `is_menu`, `is_home`, `sort`) VALUES (2, 'Perbankan', 'perbankan', 0, 1, 1, 1);
INSERT INTO nsc_category (`id`, `name`, `slug`, `parent`, `is_menu`, `is_home`, `sort`) VALUES (3, 'Makro Ekonomi', 'makro-ekonomi', 0, 1, 1, 2);
INSERT INTO nsc_category (`id`, `name`, `slug`, `parent`, `is_menu`, `is_home`, `sort`) VALUES (4, 'BUMN', 'bumn', 0, 1, 1, 3);
INSERT INTO nsc_category (`id`, `name`, `slug`, `parent`, `is_menu`, `is_home`, `sort`) VALUES (5, 'Internasional', 'internasional', 0, 1, 1, 4);


#
# TABLE STRUCTURE FOR: nsc_ci_sessions
#

DROP TABLE IF EXISTS nsc_ci_sessions;

CREATE TABLE `nsc_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO nsc_ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e41d73517dfb8a3babd1a3659f7ef2f6', '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36', 1428168721, 'a:58:{s:9:\"user_data\";s:0:\"\";s:10:\"isloggedin\";b:1;s:6:\"userid\";s:1:\"1\";s:8:\"username\";s:5:\"admin\";s:9:\"full_name\";s:13:\"Administrator\";s:8:\"group_id\";s:1:\"1\";s:10:\"group_name\";s:13:\"Administrator\";s:16:\"is_administrator\";b:1;s:10:\"last_login\";s:10:\"1428064448\";s:6:\"avatar\";s:43:\"userfiles/avatar/default/aFu_Ak47CatAni.gif\";s:10:\"created_on\";s:10:\"1427685025\";s:5:\"token\";s:32:\"570f275c9bd12961a1575b47b360e1bf\";s:11:\"_ACC_CAN_CP\";b:1;s:20:\"_ACC_USER_MANAGEMENT\";b:1;s:19:\"_ACC_ARTICLE_CREATE\";b:1;s:17:\"_ACC_ARTICLE_EDIT\";b:1;s:23:\"_ACC_ARTICLE_EDIT_OTHER\";b:1;s:19:\"_ACC_ARTICLE_DELETE\";b:1;s:25:\"_ACC_ARTICLE_DELETE_OTHER\";b:1;s:23:\"_ACC_EDITION_MANAGEMENT\";b:1;s:20:\"_ACC_CATEGORY_CREATE\";b:1;s:20:\"_ACC_CURRENCY_CREATE\";b:1;s:18:\"_ACC_CURRENCY_EDIT\";b:1;s:20:\"_ACC_CURRENCY_DELETE\";b:1;s:16:\"_ACC_BANK_CREATE\";b:1;s:14:\"_ACC_BANK_EDIT\";b:1;s:16:\"_ACC_BANK_DELETE\";b:1;s:18:\"_ACC_CATEGORY_EDIT\";b:1;s:20:\"_ACC_CATEGORY_DELETE\";b:1;s:16:\"_ACC_ADDS_CREATE\";b:1;s:14:\"_ACC_ADDS_EDIT\";b:1;s:16:\"_ACC_ADDS_DELETE\";b:1;s:20:\"_ACC_ADDS_MANAGEMENT\";b:1;s:26:\"_ACC_USER_GROUP_MANAGEMENT\";b:1;s:27:\"_ACC_USER_ACCESS_MANAGEMENT\";b:1;s:26:\"_ACC_USER_ROLES_MANAGEMENT\";b:1;s:17:\"_ACC_SYS_LOG_USER\";b:1;s:28:\"_ACC_SYS_LOG_USER_MANAGEMENT\";b:1;s:20:\"_ACC_ARTICLE_PUBLISH\";b:1;s:19:\"_ACC_SYS_PARAMETERS\";b:1;s:19:\"_ACC_SYS_LOG_SYSTEM\";b:1;s:23:\"_ACC_RUNTEXT_MANAGEMENT\";b:1;s:22:\"_ACC_RATES_AUTO_UPDATE\";b:1;s:27:\"_ACC_ARTICLE_GLOBALCATEGORY\";b:1;s:32:\"_ACC_USER_ACCESS_USER_MANAGEMENT\";b:1;s:22:\"_ACC_STATICPAGE_CREATE\";b:1;s:20:\"_ACC_STATICPAGE_EDIT\";b:1;s:22:\"_ACC_STATICPAGE_DELETE\";b:1;s:21:\"_ACC_COMMENT_APPROVAL\";b:1;s:19:\"_ACC_COMMENT_DELETE\";b:1;s:28:\"_ACC_ORDER_PACKET_MANAGEMENT\";b:1;s:18:\"_ACC_EMAIL_SYS_LOG\";b:1;s:21:\"_ACC_EMAIL_SYS_UPDATE\";b:1;s:27:\"_ACC_DATABASE_BACKUP_CREATE\";b:1;s:27:\"_ACC_DATABASE_BACKUP_DELETE\";b:1;s:22:\"_ACC_EVENTS_MANAGEMENT\";b:1;s:22:\"_ACC_PHOTO_NEWS_UPDATE\";b:1;s:22:\"_ACC_NEWSTICKER_UPDATE\";b:1;}');


#
# TABLE STRUCTURE FOR: nsc_contactus
#

DROP TABLE IF EXISTS nsc_contactus;

CREATE TABLE `nsc_contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `date` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO nsc_contactus (`id`, `ip_address`, `date`, `subject`, `name`, `email`, `content`) VALUES (1, '::1', 1428052593, 'Tes kirim pesan', 'Marwan', 'marwan.saleh@ymail.com', 'Tes kirim');


#
# TABLE STRUCTURE FOR: nsc_email_attachments
#

DROP TABLE IF EXISTS nsc_email_attachments;

CREATE TABLE `nsc_email_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_job_id` int(11) NOT NULL,
  `file_url` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emailjobid_idx` (`email_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_email_image_cid
#

DROP TABLE IF EXISTS nsc_email_image_cid;

CREATE TABLE `nsc_email_image_cid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_job_id` int(11) NOT NULL,
  `image_url` varchar(254) DEFAULT NULL,
  `cid_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_cid_idx` (`email_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_email_jobs
#

DROP TABLE IF EXISTS nsc_email_jobs;

CREATE TABLE `nsc_email_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_name` varchar(50) NOT NULL,
  `sender_email` varchar(50) NOT NULL,
  `subject` varchar(254) NOT NULL,
  `recipient_name` varchar(50) NOT NULL,
  `recipient_email` varchar(254) NOT NULL,
  `replyto` varchar(254) NOT NULL,
  `content` text NOT NULL,
  `inserted_by` int(11) NOT NULL,
  `inserted` int(11) NOT NULL,
  `processed` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_global_categories
#

DROP TABLE IF EXISTS nsc_global_categories;

CREATE TABLE `nsc_global_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO nsc_global_categories (`id`, `slug`, `name`) VALUES (1, 'slider-news', 'Slider News');
INSERT INTO nsc_global_categories (`id`, `slug`, `name`) VALUES (2, 'highlight', 'Highlight');


#
# TABLE STRUCTURE FOR: nsc_news_ticker
#

DROP TABLE IF EXISTS nsc_news_ticker;

CREATE TABLE `nsc_news_ticker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_text` varchar(254) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO nsc_news_ticker (`id`, `news_text`, `active`) VALUES (1, 'Harga Premium di Jawa Madura dan Bali Naik Jadi Rp 7.400 Per Liter Solar Rp 6.900', 1);
INSERT INTO nsc_news_ticker (`id`, `news_text`, `active`) VALUES (3, 'Harga BBM Naik Lagi Pemerintah Dinilai Terapkan Manajemen \"Warkop\"', 1);


#
# TABLE STRUCTURE FOR: nsc_photo_news
#

DROP TABLE IF EXISTS nsc_photo_news;

CREATE TABLE `nsc_photo_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_url` varchar(254) NOT NULL,
  `title` varchar(254) NOT NULL,
  `date` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `image_url` (`image_url`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO nsc_photo_news (`id`, `image_url`, `title`, `date`, `description`) VALUES (1, 'Slider/bank-mandiri-2.jpg', 'Then its just little css styling of prettyphoto to make it looks nice', 1427821200, 'for anyone whos interested, replace this function in avia.js (folder broadscope/js) with this one. Then its just little css styling of prettyphoto to make it looks nice');
INSERT INTO nsc_photo_news (`id`, `image_url`, `title`, `date`, `description`) VALUES (4, 'Slider/6806087-pretty.jpg', 'Pretty Woman', 1427907600, 'Pretty Woman is a 1990 American romantic comedy film set in Los Angeles. Written by J. F. Lawton and directed by Garry Marshall. It stars Richard Gere and Julia Roberts, and features Hector Elizondo, Ralph Bellamy (in his final performance)');
INSERT INTO nsc_photo_news (`id`, `image_url`, `title`, `date`, `description`) VALUES (6, 'Slider/dawn_of_Big_Data.jpg', 'Big Data Problem ?', 1427994000, 'Big data become important issue now');
INSERT INTO nsc_photo_news (`id`, `image_url`, `title`, `date`, `description`) VALUES (7, 'Slider/kapal_di_pelabuhan.jpg', 'Pelabuhan Baru', 1427994000, 'Masih perlukah pelabuhan baru ?');
INSERT INTO nsc_photo_news (`id`, `image_url`, `title`, `date`, `description`) VALUES (8, 'Slider/Audit-Checklist.jpg', 'Audit is Important', 1427994000, 'Audit is important things to do in your company..why ?');


#
# TABLE STRUCTURE FOR: nsc_rates
#

DROP TABLE IF EXISTS nsc_rates;

CREATE TABLE `nsc_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(20) NOT NULL,
  `last_update` date NOT NULL,
  `name` varchar(10) NOT NULL,
  `sell` float(10,2) NOT NULL,
  `buy` float(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=latin1;

INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (1, 'bca', '2014-08-22', 'AUD', '11328.45', '11248.45');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (3, 'bca', '2014-08-22', 'CHF', '13404.64', '13324.64');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (4, 'bca', '2014-08-22', 'CNY', '1941.19', '1901.19');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (6, 'bca', '2014-08-22', 'EUR', '16322.18', '16222.18');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (7, 'bca', '2014-08-22', 'GBP', '20425.06', '20325.06');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (8, 'bca', '2014-08-22', 'HKD', '1552.96', '1532.96');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (9, 'bca', '2014-08-22', 'JPY', '118.81', '115.81');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (13, 'bca', '2014-08-22', 'SGD', '9596.88', '9562.88');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (14, 'bca', '2014-08-22', 'USD', '11975.00', '11945.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (15, 'bni', '2014-08-22', 'AUD', '11328.45', '11248.45');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (17, 'bni', '2014-08-22', 'CHF', '13404.64', '13324.64');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (20, 'bni', '2014-08-22', 'EUR', '16322.18', '16222.18');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (21, 'bni', '2014-08-22', 'GBP', '20425.06', '20325.06');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (22, 'bni', '2014-08-22', 'HKD', '1552.96', '1532.96');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (23, 'bni', '2014-08-22', 'JPY', '118.81', '115.81');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (27, 'bni', '2014-08-22', 'SGD', '9596.88', '9562.88');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (28, 'bni', '2014-08-22', 'USD', '11975.00', '11945.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (29, 'bca', '2014-11-30', 'USD', '12204.00', '12186.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (30, 'bca', '2014-11-30', 'SGD', '9368.07', '9338.07');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (31, 'bca', '2014-11-30', 'EUR', '15221.80', '15121.80');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (32, 'bca', '2014-11-30', 'AUD', '10417.34', '10337.34');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (33, 'bca', '2014-11-30', 'DKK', '2074.08', '2004.08');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (34, 'bca', '2014-11-30', 'SEK', '1672.18', '1602.18');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (35, 'bca', '2014-11-30', 'CAD', '10749.12', '10669.12');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (36, 'bca', '2014-11-30', 'CHF', '12674.23', '12574.23');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (37, 'bca', '2014-11-30', 'NZD', '9602.59', '9532.59');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (38, 'bca', '2014-11-30', 'GBP', '19230.79', '19090.79');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (39, 'bca', '2014-11-30', 'HKD', '1583.03', '1563.03');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (40, 'bca', '2014-11-30', 'JPY', '104.70', '101.70');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (41, 'bca', '2014-11-30', 'SAR', '3284.38', '3214.38');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (42, 'bca', '2014-11-30', 'CNY', '2005.16', '1965.16');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (58, 'mandiri', '2014-11-30', 'USD', '12232.00', '12068.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (59, 'mandiri', '2014-11-30', 'AUD', '10468.00', '10175.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (60, 'mandiri', '2014-11-30', 'CAD', '10841.00', '10575.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (61, 'mandiri', '2014-11-30', 'CHF', '12804.00', '12368.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (62, 'mandiri', '2014-11-30', 'NZD', '9646.00', '9387.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (63, 'mandiri', '2014-11-30', 'DKK', '2117.00', '1953.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (64, 'mandiri', '2014-11-30', 'GBP', '19276.00', '18899.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (65, 'mandiri', '2014-11-30', 'HKD', '1623.00', '1513.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (66, 'mandiri', '2014-11-30', 'JPY', '104.31', '101.11');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (67, 'mandiri', '2014-11-30', 'SGD', '9447.00', '9204.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (68, 'mandiri', '2014-11-30', 'EUR', '15291.00', '14963.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (69, 'mandiri', '2014-11-30', 'SAR', '3380.00', '3104.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (70, 'mandiri', '2014-11-30', 'SEK', '1684.00', '1578.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (71, 'mandiri', '2014-11-30', 'NOK', '1835.00', '1667.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (72, 'mandiri', '2014-11-30', 'CNY', '2024.00', '1931.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (73, 'bni', '2014-11-30', 'USD', '12309.00', '12061.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (74, 'bni', '2014-11-30', 'AUD', '10615.00', '10115.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (75, 'bni', '2014-11-30', 'CHF', '12800.00', '12450.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (76, 'bni', '2014-11-30', 'CAD', '10912.00', '10562.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (77, 'bni', '2014-11-30', 'GBP', '19398.00', '18898.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (78, 'bni', '2014-11-30', 'EUR', '15423.00', '14923.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (79, 'bni', '2014-11-30', 'JPY', '105.77', '100.27');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (80, 'bni', '2014-11-30', 'HKD', '1647.00', '1497.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (81, 'bni', '2014-11-30', 'SAR', '3447.00', '3047.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (82, 'bni', '2014-11-30', 'SGD', '9653.00', '9053.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (83, 'bri', '2014-11-30', 'AED', '3530.60', '3131.53');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (84, 'bri', '2014-11-30', 'AUD', '10457.78', '10297.16');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (85, 'bri', '2014-11-30', 'CHF', '12732.37', '12540.06');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (86, 'bri', '2014-11-30', 'CNY', '2064.32', '1913.49');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (87, 'bri', '2014-11-30', 'EUR', '15294.35', '15081.23');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (88, 'bri', '2014-11-30', 'GBP', '19292.34', '19034.40');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (89, 'bri', '2014-11-30', 'HKD', '1581.79', '1564.19');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (90, 'bri', '2014-11-30', 'JPY', '103.91', '102.44');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (91, 'bri', '2014-11-30', 'NZD', '9647.39', '9489.30');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (92, 'bri', '2014-11-30', 'SAR', '3262.09', '3237.67');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (93, 'bri', '2014-11-30', 'SGD', '9430.77', '9299.29');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (94, 'bri', '2014-11-30', 'USD', '12240.00', '12150.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (95, 'bca', '2015-01-02', 'USD', '12510.00', '12470.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (96, 'bca', '2015-01-02', 'SGD', '9429.34', '9399.34');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (97, 'bca', '2015-01-02', 'EUR', '15112.95', '15012.95');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (98, 'bca', '2015-01-02', 'AUD', '10193.12', '10113.12');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (99, 'bca', '2015-01-02', 'DKK', '2058.05', '1988.05');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (100, 'bca', '2015-01-02', 'SEK', '1631.79', '1561.79');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (101, 'bca', '2015-01-02', 'CAD', '10773.48', '10693.48');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (102, 'bca', '2015-01-02', 'CHF', '12570.68', '12470.68');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (103, 'bca', '2015-01-02', 'NZD', '9724.75', '9654.75');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (104, 'bca', '2015-01-02', 'GBP', '19486.33', '19346.33');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (105, 'bca', '2015-01-02', 'HKD', '1620.48', '1600.48');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (106, 'bca', '2015-01-02', 'JPY', '105.26', '102.26');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (107, 'bca', '2015-01-02', 'SAR', '3363.51', '3293.51');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (108, 'bca', '2015-01-02', 'CNY', '2032.57', '1992.57');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (109, 'mandiri', '2015-01-02', 'USD', '12557.00', '12343.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (110, 'mandiri', '2015-01-02', 'AUD', '10298.00', '9966.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (111, 'mandiri', '2015-01-02', 'CAD', '10851.00', '10549.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (112, 'mandiri', '2015-01-02', 'CHF', '12727.00', '12255.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (113, 'mandiri', '2015-01-02', 'NZD', '9813.00', '9513.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (114, 'mandiri', '2015-01-02', 'DKK', '2103.00', '1936.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (115, 'mandiri', '2015-01-02', 'GBP', '19591.00', '19135.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (116, 'mandiri', '2015-01-02', 'HKD', '1666.00', '1547.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (117, 'mandiri', '2015-01-02', 'JPY', '105.24', '101.66');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (118, 'mandiri', '2015-01-02', 'SGD', '9523.00', '9246.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (119, 'mandiri', '2015-01-02', 'EUR', '15213.00', '14827.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (120, 'mandiri', '2015-01-02', 'SAR', '3470.00', '3175.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (121, 'mandiri', '2015-01-02', 'SEK', '1646.00', '1539.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (122, 'mandiri', '2015-01-02', 'NOK', '1745.00', '1587.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (123, 'mandiri', '2015-01-02', 'CNY', '2057.00', '1956.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (124, 'bni', '2015-01-02', 'USD', '12599.00', '12401.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (125, 'bni', '2015-01-02', 'AUD', '10413.00', '9913.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (126, 'bni', '2015-01-02', 'CHF', '12708.00', '12358.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (127, 'bni', '2015-01-02', 'CAD', '10917.00', '10567.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (128, 'bni', '2015-01-02', 'GBP', '19688.00', '19188.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (129, 'bni', '2015-01-02', 'EUR', '15322.00', '14822.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (130, 'bni', '2015-01-02', 'JPY', '106.55', '101.05');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (131, 'bni', '2015-01-02', 'HKD', '1627.00', '1597.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (132, 'bni', '2015-01-02', 'SAR', '3531.00', '3131.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (133, 'bni', '2015-01-02', 'SGD', '9725.00', '9125.00');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (134, 'bri', '2015-01-02', 'AED', '3602.28', '3183.41');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (135, 'bri', '2015-01-02', 'AUD', '10233.57', '10032.26');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (136, 'bri', '2015-01-02', 'CHF', '12595.46', '12359.94');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (137, 'bri', '2015-01-02', 'CNY', '2087.57', '1928.18');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (138, 'bri', '2015-01-02', 'EUR', '15139.77', '14870.48');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (139, 'bri', '2015-01-02', 'GBP', '19520.76', '19186.08');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (140, 'bri', '2015-01-02', 'HKD', '1616.75', '1592.59');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (141, 'bri', '2015-01-02', 'JPY', '104.41', '102.55');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (142, 'bri', '2015-01-02', 'NZD', '9767.27', '9573.89');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (143, 'bri', '2015-01-02', 'SAR', '3335.38', '3297.63');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (144, 'bri', '2015-01-02', 'SGD', '9463.95', '9299.26');
INSERT INTO nsc_rates (`id`, `bank`, `last_update`, `name`, `sell`, `buy`) VALUES (145, 'bri', '2015-01-02', 'USD', '12515.00', '12375.00');


#
# TABLE STRUCTURE FOR: nsc_rates_update
#

DROP TABLE IF EXISTS nsc_rates_update;

CREATE TABLE `nsc_rates_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(20) NOT NULL,
  `last_update` date NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bank_ndx` (`bank`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO nsc_rates_update (`id`, `bank`, `last_update`, `visible`) VALUES (1, 'bca', '2015-01-02', 1);
INSERT INTO nsc_rates_update (`id`, `bank`, `last_update`, `visible`) VALUES (2, 'bni', '2015-01-02', 0);
INSERT INTO nsc_rates_update (`id`, `bank`, `last_update`, `visible`) VALUES (3, 'mandiri', '2015-01-02', 1);
INSERT INTO nsc_rates_update (`id`, `bank`, `last_update`, `visible`) VALUES (4, 'bri', '2015-01-02', 1);


#
# TABLE STRUCTURE FOR: nsc_static_pages
#

DROP TABLE IF EXISTS nsc_static_pages;

CREATE TABLE `nsc_static_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caption` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `title` varchar(254) NOT NULL,
  `content` text NOT NULL,
  `is_menu` tinyint(1) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `static_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_system_variables
#

DROP TABLE IF EXISTS nsc_system_variables;

CREATE TABLE `nsc_system_variables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `var_name` varchar(50) NOT NULL,
  `var_value` varchar(254) NOT NULL,
  `var_type` enum('string','integer','float','boolean') NOT NULL DEFAULT 'string',
  `is_list` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (1, 'SYSLOG_SAVE_DAYS', '30', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (2, 'GA_CODE', 'UA-57197378-1', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (3, 'FB_APP_ID', '570841689714924', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (4, 'TW_TIMELINE_LIMIT', '4', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (5, 'TW_TIMELINE_HEIGHT', '80', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (6, 'TW_TWEET_NAME', 'mjlhstabilitas', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (7, 'TW_WIDGET_ID', '537066244189335552', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (8, 'FB_DATA_HREF', 'pages/Majalah-Stabilitas/317357338464248', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (9, 'FB_DATA_WIDTH', '250', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (10, 'FB_DATA_SHOW_FACE', 'true', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (11, 'FB_DATA_HEADER', 'false', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (12, 'FB_DATA_STREAM', 'true', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (13, 'FB_DATA_SHOW_BORDER', 'false', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (14, 'FB_DATA_COLOR_SCHEME', 'light', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (15, 'FB_DATA_HEIGHT', '430', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (16, 'FB_APP_SECRET', '543b16b8a1b919a77b83e3fc5043eda1', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (17, 'FB_APP_SCOPE', 'email,user_friends', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (18, 'GOOGLE_API_KEY', 'AIzaSyAnzGc6TmL55KVR7NO1-HqwLGcUir794Dg', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (19, 'TW_API_KEY', 'Khkp3P3uLycizfWI4UmNa5riZ', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (20, 'TW_API_SECRET', '31mqsxgGpahXHXtOl1E7m8Wqv2EAhPOHpey6hhVwoeBMzI8iSH', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (21, 'EMAIL_SMTP_HOST', 'smtp.gmail.com', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (22, 'EMAIL_SMTP_PORT', '587', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (23, 'EMAIL_AUTH_REQUIRED', 'true', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (24, 'EMAIL_AUTH_USER', 'mail-service@stabilitas.co.id', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (25, 'EMAIL_AUTH_PASSWORD', 'k3m@ng35', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (26, 'EMAIL_SENDER_NAME', 'Stabilitas Mail Service', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (27, 'EMAIL_SENDER_ADDRESS', 'mail-service@stabilitas.co.id', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (28, 'EMAIL_CC_ADDRESS', 'marwan.saleh@stabilitas.co.id', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (29, 'EMAIL_SECURE_TYPE', 'tls', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (30, 'LAYOUT_HOME_LATEST_NUM', '15', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (31, 'LAYOUT_HOME_CAT_NUM', '3', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (32, 'LAYOUT_HOME_CAT_ARTICLE_NUM', '3', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (33, 'LAYOUT_HOME_WIDGETS', 'facebook,stock,group_news,photo_news,feature_video,latest_news', 'string', 1);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (34, 'LAYOUT_CATEGORY_WIDGETS', 'socmed_counter,stock,group_news,photo_news,feature_video,latest_news', 'string', 1);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (35, 'LAYOUT_DETAIL_WIDGETS', 'socmed_counter,stock,group_news,photo_news,feature_video,latest_news', 'string', 1);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (36, 'LAYOUT_NEWSPHOTO_NUM', '10', 'string', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (37, 'LAYOUT_CUSTOM_WIDGETS', 'socmed_counter,stock,group_news,photo_news,feature_video,latest_news', 'string', 1);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (38, 'LAYOUT_NEWSGROUP_NUM', '5', 'integer', 0);
INSERT INTO nsc_system_variables (`id`, `var_name`, `var_value`, `var_type`, `is_list`) VALUES (39, 'LAYOUT_NEWSLATEST_NUM', '6', 'integer', 0);


#
# TABLE STRUCTURE FOR: nsc_tags
#

DROP TABLE IF EXISTS nsc_tags;

CREATE TABLE `nsc_tags` (
  `tag` varchar(30) NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO nsc_tags (`tag`) VALUES ('asian banker');
INSERT INTO nsc_tags (`tag`) VALUES ('asset management');
INSERT INTO nsc_tags (`tag`) VALUES ('asuransi');
INSERT INTO nsc_tags (`tag`) VALUES ('audit');
INSERT INTO nsc_tags (`tag`) VALUES ('bi');
INSERT INTO nsc_tags (`tag`) VALUES ('big data');
INSERT INTO nsc_tags (`tag`) VALUES ('bii');
INSERT INTO nsc_tags (`tag`) VALUES ('bkpm');
INSERT INTO nsc_tags (`tag`) VALUES ('bpjs');
INSERT INTO nsc_tags (`tag`) VALUES ('bumn');
INSERT INTO nsc_tags (`tag`) VALUES ('cilamaya');
INSERT INTO nsc_tags (`tag`) VALUES ('data lake');
INSERT INTO nsc_tags (`tag`) VALUES ('emc');
INSERT INTO nsc_tags (`tag`) VALUES ('investasi');
INSERT INTO nsc_tags (`tag`) VALUES ('jibor');
INSERT INTO nsc_tags (`tag`) VALUES ('mandiri');
INSERT INTO nsc_tags (`tag`) VALUES ('maybank');
INSERT INTO nsc_tags (`tag`) VALUES ('migas');
INSERT INTO nsc_tags (`tag`) VALUES ('mitra keluarga');
INSERT INTO nsc_tags (`tag`) VALUES ('ojk');
INSERT INTO nsc_tags (`tag`) VALUES ('rekening');
INSERT INTO nsc_tags (`tag`) VALUES ('reksa dana');
INSERT INTO nsc_tags (`tag`) VALUES ('ritel');
INSERT INTO nsc_tags (`tag`) VALUES ('saham');
INSERT INTO nsc_tags (`tag`) VALUES ('sinarmas');
INSERT INTO nsc_tags (`tag`) VALUES ('syariah');
INSERT INTO nsc_tags (`tag`) VALUES ('vaganza');


#
# TABLE STRUCTURE FOR: nsc_unique_visitors
#

DROP TABLE IF EXISTS nsc_unique_visitors;

CREATE TABLE `nsc_unique_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `visitor_id` varchar(60) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `visitor_id` (`visitor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO nsc_unique_visitors (`id`, `date`, `visitor_id`, `ip_address`) VALUES (1, 1427957994, '0', '::1');


#
# TABLE STRUCTURE FOR: nsc_user_access
#

DROP TABLE IF EXISTS nsc_user_access;

CREATE TABLE `nsc_user_access` (
  `access_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `has_access` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_user_groupaccess
#

DROP TABLE IF EXISTS nsc_user_groupaccess;

CREATE TABLE `nsc_user_groupaccess` (
  `access_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `has_access` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO nsc_user_groupaccess (`access_id`, `group_id`, `role_id`, `has_access`) VALUES (1, 2, 1, 1);
INSERT INTO nsc_user_groupaccess (`access_id`, `group_id`, `role_id`, `has_access`) VALUES (2, 3, 1, 1);
INSERT INTO nsc_user_groupaccess (`access_id`, `group_id`, `role_id`, `has_access`) VALUES (3, 4, 1, 1);
INSERT INTO nsc_user_groupaccess (`access_id`, `group_id`, `role_id`, `has_access`) VALUES (4, 5, 1, 1);
INSERT INTO nsc_user_groupaccess (`access_id`, `group_id`, `role_id`, `has_access`) VALUES (5, 5, 19, 1);


#
# TABLE STRUCTURE FOR: nsc_user_groups
#

DROP TABLE IF EXISTS nsc_user_groups;

CREATE TABLE `nsc_user_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) NOT NULL,
  `is_removable` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `groupname_ndx` (`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO nsc_user_groups (`group_id`, `group_name`, `is_removable`) VALUES (1, 'Administrator', 0);
INSERT INTO nsc_user_groups (`group_id`, `group_name`, `is_removable`) VALUES (2, 'Redaktur Ahli', 0);
INSERT INTO nsc_user_groups (`group_id`, `group_name`, `is_removable`) VALUES (3, 'Redaktur', 0);
INSERT INTO nsc_user_groups (`group_id`, `group_name`, `is_removable`) VALUES (4, 'Kontributor', 0);
INSERT INTO nsc_user_groups (`group_id`, `group_name`, `is_removable`) VALUES (5, 'Staf Admin', 0);


#
# TABLE STRUCTURE FOR: nsc_user_roles
#

DROP TABLE IF EXISTS nsc_user_roles;

CREATE TABLE `nsc_user_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_description` varchar(254) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `rolename_ndx` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (1, 'CAN_CP', 'User enable to access CMS (control panel)');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (2, 'USER_MANAGEMENT', 'Mengelola user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (4, 'ARTICLE_CREATE', 'Membuat artikel baru');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (5, 'ARTICLE_EDIT', 'Merubah artikel');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (6, 'ARTICLE_EDIT_OTHER', 'Merubah artikel yang dibuat orang lain');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (7, 'ARTICLE_DELETE', 'Menghapus artikel');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (8, 'ARTICLE_DELETE_OTHER', 'Menghapus artikel yang dibuat orang lain');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (9, 'EDITION_MANAGEMENT', 'Mengelola edisi');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (10, 'CATEGORY_CREATE', 'Menambah kategori artikel');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (11, 'CURRENCY_CREATE', 'Menambah mata uang');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (12, 'CURRENCY_EDIT', 'Merubah data mata uang');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (13, 'CURRENCY_DELETE', 'Menghapus data mata uang');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (14, 'BANK_CREATE', 'Menambah data bank');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (15, 'BANK_EDIT', 'Merubah data bank');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (16, 'BANK_DELETE', 'Menghapus data bank');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (17, 'CATEGORY_EDIT', 'Merubah data kategori artikel');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (18, 'CATEGORY_DELETE', 'Menghapus data kategori artikel');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (19, 'ADDS_CREATE', 'Menambah data iklan');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (20, 'ADDS_EDIT', 'Merubah data iklan');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (21, 'ADDS_DELETE', 'Menghapus data iklan');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (22, 'ADDS_MANAGEMENT', 'Mengelola kategori dan tipe iklan');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (23, 'USER_GROUP_MANAGEMENT', 'Mengelola grup user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (24, 'USER_ACCESS_MANAGEMENT', 'Mengelola hak akses grup user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (25, 'USER_ROLES_MANAGEMENT', 'Mengelola role hak akses');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (26, 'SYS_LOG_USER', 'Melihat log user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (27, 'SYS_LOG_USER_MANAGEMENT', 'Mengelola log user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (28, 'ARTICLE_PUBLISH', 'Mempublish artikel untuk bisa dibaca umum');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (29, 'SYS_PARAMETERS', 'Merubah parameter sistem');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (30, 'SYS_LOG_SYSTEM', 'Melihat sistem log');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (31, 'RUNTEXT_MANAGEMENT', 'Mengelola running text');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (32, 'RATES_AUTO_UPDATE', 'Mengeksekusi script update rate dari sumber eksternal');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (33, 'ARTICLE_GLOBALCATEGORY', 'Menghapus artikel dari kategori global');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (34, 'USER_ACCESS_USER_MANAGEMENT', 'Mengelola hak akses per user');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (35, 'STATICPAGE_CREATE', 'Hak akses untuk membuat static page baru');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (36, 'STATICPAGE_EDIT', 'Hak akses untuk merubah static page');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (37, 'STATICPAGE_DELETE', 'Hak akses untuk menghapus static page');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (38, 'COMMENT_APPROVAL', 'Set approval a comment');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (39, 'COMMENT_DELETE', 'Delete a comment');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (40, 'ORDER_PACKET_MANAGEMENT', 'Mengelola paket pemesanan majalah');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (41, 'EMAIL_SYS_LOG', 'Mengelola log email');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (42, 'EMAIL_SYS_UPDATE', 'Merubah data job email');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (43, 'DATABASE_BACKUP_CREATE', 'Create database backup');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (44, 'DATABASE_BACKUP_DELETE', 'Delete database backup');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (45, 'EVENTS_MANAGEMENT', 'Mengelola data events');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (46, 'PHOTO_NEWS_UPDATE', 'Mengelola berita foto');
INSERT INTO nsc_user_roles (`role_id`, `role_name`, `role_description`) VALUES (47, 'NEWSTICKER_UPDATE', 'Mengelola newsticker');


#
# TABLE STRUCTURE FOR: nsc_user_socmed
#

DROP TABLE IF EXISTS nsc_user_socmed;

CREATE TABLE `nsc_user_socmed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `client_app` varchar(30) NOT NULL,
  `client_id` varchar(30) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nsc_users
#

DROP TABLE IF EXISTS nsc_users;

CREATE TABLE `nsc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(40) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(128) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `group_id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `mobile` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `avatar` tinytext NOT NULL,
  `about` text NOT NULL,
  `last_login` int(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `created_on` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `token` varchar(40) NOT NULL,
  `last_page` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `session_id` (`session_id`),
  KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO nsc_users (`id`, `session_id`, `username`, `password`, `full_name`, `group_id`, `type`, `mobile`, `phone`, `email`, `avatar`, `about`, `last_login`, `last_ip`, `created_on`, `is_active`, `token`, `last_page`) VALUES (1, 'e41d73517dfb8a3babd1a3659f7ef2f6', 'admin', 'b5907cf220ca6583676006c98626e4f22d23dfbd9bb942fd1482ef2887b06762', 'Administrator', 1, 0, '', '', 'admin@stabilitas.co.id', 'userfiles/avatar/default/aFu_Ak47CatAni.gif', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam consequat est sit amet purus tincidunt dapibus. Sed convallis neque tellus, at ultrices tellus egestas vel. Proin quis magna enim. Vivamus sem sem, imperdiet varius eros at, tristique posuere risus. Mauris eu rutrum diam, quis euismod est. Donec eget risus id orci dapibus venenatis id vitae erat. Maecenas et est tempor, feugiat leo non, semper quam.', 1428167389, '::1', 1427685025, 1, '570f275c9bd12961a1575b47b360e1bf', '');
INSERT INTO nsc_users (`id`, `session_id`, `username`, `password`, `full_name`, `group_id`, `type`, `mobile`, `phone`, `email`, `avatar`, `about`, `last_login`, `last_ip`, `created_on`, `is_active`, `token`, `last_page`) VALUES (2, '', 'sandy', 'b5907cf220ca6583676006c98626e4f22d23dfbd9bb942fd1482ef2887b06762', 'Sandy', 2, 0, '081320979920', '', '', '', '', 1427789669, '::1', 1427786837, 1, '', '');
INSERT INTO nsc_users (`id`, `session_id`, `username`, `password`, `full_name`, `group_id`, `type`, `mobile`, `phone`, `email`, `avatar`, `about`, `last_login`, `last_ip`, `created_on`, `is_active`, `token`, `last_page`) VALUES (3, '', 'syarif', 'b5907cf220ca6583676006c98626e4f22d23dfbd9bb942fd1482ef2887b06762', 'Syarif Fadilah', 2, 0, '08159364675', '', 'syariff_fad@yahoo.com', '', '', 0, '', 1427786860, 1, '', '');
INSERT INTO nsc_users (`id`, `session_id`, `username`, `password`, `full_name`, `group_id`, `type`, `mobile`, `phone`, `email`, `avatar`, `about`, `last_login`, `last_ip`, `created_on`, `is_active`, `token`, `last_page`) VALUES (4, '', 'marwan', 'b5907cf220ca6583676006c98626e4f22d23dfbd9bb942fd1482ef2887b06762', 'Marwan Saleh', 4, 0, '08121443323', '', 'marwan.saleh@stabilitas.co.id', 'userfiles/avatar/default/animeboy.gif', '', 1427907011, '::1', 1427789155, 1, '', '');


